# BCIB-timecard-assistant
Houle internal tool for automatically filling out BCIB timecards.

## Folder structure

```
timecards/   timecards.html, timecards.js   — paste-in regular hours
sickdays/    sickdays.html, sickdays.js     — paste-in sick days
daysoff/     daysoff.html, daysoff.js       — paste-in days off
settings/    settings.html, settings.js     — nickname map editor
popup/       popup.html, popup.js           — extension toolbar popup / menu
config/      manifest.json                  — source of truth for the extension manifest
shared/      shared.js, content.js, styles.css
logos/       bcib-logo.gif, houle-logo.png
manifest.json  (generated — see below, don't edit directly)
build.sh
```

`shared/shared.js` holds the code every page needs: `parseNicknameMap()`,
`getNicknameMap()`, `normalizeName()`, `timeToMinutes()` and
`minutesToTime()`. It's loaded as a plain `<script>` tag before each page's
own script (and listed first in `content_scripts` in the manifest), so its
functions are just available as globals — no bundler needed.

`shared/content.js` is the content script that runs on fdtpro.com and does
the actual form-filling.

`shared/styles.css` is the stylesheet shared by all five HTML pages
(it used to be `popup.css`, renamed since it isn't popup-specific).

## One important gotcha: manifest.json

Chrome only ever looks for `manifest.json` in the top-level folder you point
it at with "Load unpacked" — it won't find one nested inside `config/`, and
the Chrome Web Store has the same requirement for published packages.

So `config/manifest.json` is kept as the file you actually edit, and
`build.sh` copies it to a real `manifest.json` at the project root, which is
what you load into Chrome (`chrome://extensions` → Load unpacked → select
this root folder).

**Run `./build.sh` once after cloning, and again any time you change
`config/manifest.json`**, then reload the extension in Chrome.

## Known behavior change from the old flat layout

The old `timecards.js` had its own copy of `normalizeName()` that didn't
strip periods out of names, while `sickdays.js`, `daysoff.js` and
`content.js` all did. That meant a name like "J. Smith" pasted into the
Timecards page could fail to match the same person's name as read off the
FDT Pro page. Now that there's one shared `normalizeName()`, it uses the
period-stripping version everywhere — so this refactor also fixes that
mismatch, but it's worth knowing about in case anyone was relying on the
old timecards-only behavior.
