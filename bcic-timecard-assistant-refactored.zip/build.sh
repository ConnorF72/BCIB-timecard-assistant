#!/usr/bin/env bash
# Chrome only ever looks for manifest.json in the top-level folder you pick
# with "Load unpacked" (and the Chrome Web Store requires the same for
# published packages) — it will not find one nested in config/. So
# config/manifest.json is kept as the single source of truth, and this
# script publishes a copy to the project root, which is what you actually
# point Chrome at.
#
# Run this once after cloning, and again any time you edit config/manifest.json.

set -e
cd "$(dirname "$0")"
cp config/manifest.json manifest.json
echo "Copied config/manifest.json -> manifest.json"
